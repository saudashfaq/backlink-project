<div class="py-4 pb-3 heading my-4">
    <div class="container mt-4">
        <h1 class="h1-heading">
            {{ $site }} »
            <span class="text-muted"> {{ $currentlySite }}</span>
        </h1>
    </div>
</div>
