<div class="multisteps-form__progress my-4">

    <button class="multisteps-form__progress-btn1 js-active" id="step_1" type="button" title="Step 1">Step 1</button>

    <button class="multisteps-form__progress-btn" type="button" id="step_2" title="Step 2">Step 2</button>

    <button class="multisteps-form__progress-btn" type="button" id="step_3" title="Step 3">Step 3</button>

    <button class="multisteps-form__progress-btn" type="button" id="step_4" title="Step 4">Step 4</button>
    
</div>
