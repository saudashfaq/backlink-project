<div>

    <!--<style>

        /*Step Form Style*/
        .header__btn {transition-property: all;transition-duration: 0.2s;transition-timing-function: linear;transition-delay: 0s;padding: 10px 20px;display: inline-block;margin-right: 10px;background-color: #fff;border: 1px solid #2c2c2c;border-radius: 3px;cursor: pointer;outline: none;}.header__btn:last-child {margin-right: 0;}.header__btn:hover, .header__btn.js-active {color: #fff;background-color: #2c2c2c;}.header {max-width: 600px;margin: 50px auto;text-align: center;}.header__title {margin-bottom: 30px;font-size: 2.1rem;}.content {width: 95%;margin: 0 auto 50px;}.content__title {margin-bottom: 40px;font-size: 20px;text-align: center;}.content__title--m-sm {margin-bottom: 10px;}.multisteps-form__progress {display: grid;grid-template-columns: repeat(auto-fit, minmax(0, 1fr));}.multisteps-form__progress-btn {transition-property: all;transition-duration: 0.15s;transition-timing-function: linear;transition-delay: 0s;position: relative;padding-top: 20px;color: rgba(108, 117, 125, 0.7);text-indent: -9999px;border: none;background-color: transparent;outline: none !important;cursor: pointer;}@media (min-width: 500px) {.multisteps-form__progress-btn {text-indent: 0;}}.multisteps-form__progress-btn:before {position: absolute;top: 0;left: 50%;display: block;width: 13px;height: 13px;content: '';-webkit-transform: translateX(-50%);transform: translateX(-50%);transition: all 0.15s linear 0s, -webkit-transform 0.15s cubic-bezier(0.05, 1.09, 0.16, 1.4) 0s;transition: all 0.15s linear 0s, transform 0.15s cubic-bezier(0.05, 1.09, 0.16, 1.4) 0s;transition: all 0.15s linear 0s, transform 0.15s cubic-bezier(0.05, 1.09, 0.16, 1.4) 0s, -webkit-transform 0.15s cubic-bezier(0.05, 1.09, 0.16, 1.4) 0s;border: 2px solid currentColor;border-radius: 50%;background-color: #fff;box-sizing: border-box;z-index: 3;}.multisteps-form__progress-btn:after {position: absolute;top: 5px;left: calc(-50% - 13px / 2);transition-property: all;transition-duration: 0.15s;transition-timing-function: linear;transition-delay: 0s;display: block;width: 100%;height: 2px;content: '';background-color: currentColor;z-index: 1;}.multisteps-form__progress-btn:first-child:after {display: none;}.multisteps-form__progress-btn.js-active {color: #007bff;}.multisteps-form__progress-btn.js-active:before {-webkit-transform: translateX(-50%) scale(1.2);transform: translateX(-50%) scale(1.2);background-color: currentColor;}.multisteps-form__form {position: relative;}.multisteps-form__panel {position: absolute;top: 0;left: 0;width: 100%;height: 0;opacity: 0;visibility: hidden;}.multisteps-form__panel.js-active {height: auto;opacity: 1;visibility: visible;}.multisteps-form__panel[data-animation="scaleOut"] {-webkit-transform: scale(1.1);transform: scale(1.1);}.multisteps-form__panel[data-animation="scaleOut"].js-active {transition-property: all;transition-duration: 0.2s;transition-timing-function: linear;transition-delay: 0s;-webkit-transform: scale(1);transform: scale(1);}.multisteps-form__panel[data-animation="slideHorz"] {left: 50px;}.multisteps-form__panel[data-animation="slideHorz"].js-active {transition-property: all;transition-duration: 0.25s;transition-timing-function: cubic-bezier(0.2, 1.13, 0.38, 1.43);transition-delay: 0s;left: 0;}.multisteps-form__panel[data-animation="slideVert"] {top: 30px;}.multisteps-form__panel[data-animation="slideVert"].js-active {transition-property: all;transition-duration: 0.2s;transition-timing-function: linear;transition-delay: 0s;top: 0;}.multisteps-form__panel[data-animation="fadeIn"].js-active {transition-property: all;transition-duration: 0.3s;transition-timing-function: linear;transition-delay: 0s;}.multisteps-form__panel[data-animation="scaleIn"] {-webkit-transform: scale(0.9);transform: scale(0.9);}.multisteps-form__panel[data-animation="scaleIn"].js-active {transition-property: all;transition-duration: 0.2s;transition-timing-function: linear;transition-delay: 0s;-webkit-transform: scale(1);transform: scale(1);}.owner-verification-form{display: none;}.bg-theme-color{background-color: #eff1f166!important;}.show_error{color: red;}.pull-absolute-right{position: absolute;right: 0;}.btn-lg{padding: 10px 60px;}
        </style>

    
    <div class="section section-grey section-lowp section-border-bottom">
        <div class="container">
            <div class="col-md-12 noP row">
                <div class="col-md-8 noP">
                    <h1 class="heading2">Publisher » <a href="https://www.buysellguestpost.com/publisher/websites">Websites</a> <span class="text-muted">» Add New Website</span></h1>
                </div>
                <div class="col-md-4 noP"></div>
            </div>
        </div>
    </div>

    <div class="section section-border-bottom">
        <div class="container" style="min-height:950px;">
        <div class="row">
        <div class="col-md-2 dashboard_sidebar">
        <style>
                            .sidebar-list li a:hover{
                                color: black !important;
                            }
                        </style>
        <ul class="sidebar-list">
        <li>
        <strong>Account Balance</strong>
        <br>
        <span style="color:yellow !important;" class="fa-2x text-success">$0</span>
        </li>
        <hr style="background-color: white;">
        <li>
        <a href="https://www.buysellguestpost.com/publisher" class="dashboard" style="color: white;">Dashboard</a>
        </li>
        <li>
        <a href="https://www.buysellguestpost.com/publisher/websites" class="websites active">Websites</a>
        </li>
        <hr style="background-color: white;">
        <li>
        <a href="https://www.buysellguestpost.com/publisher/orders" class="orders" style="color: white;">Orders</a>
        </li>
        <li>
        <a href="https://www.buysellguestpost.com/publisher/earning" class="earning" style="color: white;">Earning</a>
        </li>
        </ul>
        <a href="https://www.buysellguestpost.com/da-dr-increase-service"><img src="https://www.buysellguestpost.com/assets/images/j.jpg" style="width: 100%;margin-top: 20px;margin-bottom: 20px;" alt=""></a> <script>
                            $(".sidebar-list .websites").addClass("active");
                            $('.sidebar-list .websites').css("color:#0090BF;");
                            $(".sidebar-list .dashboard,.sidebar-list .inbox,.sidebar-list .orders,.sidebar-list .earning").css('color', 'white');
                        </script>
        </div>
        <div class="col" style="padding:0 0 0 40px;">
        <div class="col-md-12">
        </div>
        <div class="col-md-12 noP">
        <h1 class="main-heading text-center addsection">
        <strong>Submit New Website</strong>
        </h1>
        <div class="row addsection">
        <div class="col-12 mb-4">
            <livewire:form-progress />
        </div>
        </div>
        <div class="row text-color-white">
        <div class="col-12 m-auto">
        <form class="multisteps-form__form addsection" style="height: 235px;">
        
        <div class="multisteps-form__panel shadow p-4 rounded bg-theme-color js-active" data-animation="scaleIn">
        <h3 class="multisteps-form__title text-center font-weight-bold">Website</h3>
        <div class="multisteps-form__content">
        <div class="form-row mt-4">
        <div class="col-12 col-sm-2"></div>
        <div class="col-12 col-sm-8">
        <input class="multisteps-form__input form-control" type="text" style="font-size: 22px;" name="web_url" id="web_url" placeholder="http://example.com">
        </div>
        </div>
        <div class="button-row mt-4 text-center">
        <button class="btn btn-primary btn-lg" id="website_tab_next" urlchecked="false" type="button" title="Next">Next</button>
        </div>
        </div>
        </div>
        
        <div class="multisteps-form__panel shadow p-4 rounded bg-theme-color" data-animation="scaleIn">
        <h3 class="multisteps-form__title text-center font-weight-bold">Details</h3>
         <div class="multisteps-form__content">
        <div class="form-row mt-4">
        <div class="col-md-12" style="margin-top: 15px;">
        <div class="form-group">
        <label>Your role in website *</label>&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="multisteps-form__input" name="role" value="1" checked="" id="owner_type_1" type="radio"> <label for="owner_type_1">Author / Contributer</label>&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="multisteps-form__input" name="role" value="2" id="owner_type_2" type="radio"> <label for="owner_type_2">Website Owner</label>
        </div>
        <div class="form-group owner-verification-form" id="domain_email_box">
        <input class="multisteps-form__input form-control" type="text" id="domain_email" placeholder="Enter You Domain Email">
        <small>e.g; info@abc.com</small>
        <button style="float: right;display: none;" id="send_verification_email">Send Verification Code</button>
        </div>
        <div class="form-group" id="domain_email_code_box" style="display: none;">
        <input type="text" class="form-control text-center" max="4" placeholder="####">
        </div>
        <div class="form-group owner-verification-form">
        <div class="alert alert-danger">
        <b>Note:</b> If you don't have Domain Email, You can verify as an Owner of your Website by using header script after Submitting.
        </div>
        </div>
        <input type="text" hidden="" id="verfied_email" value="">
        </div>
        <div class="col-md-12" style="margin-top: 15px;">
        <label>Link Type *</label>
        <select class="multisteps-form__input form-control" name="linkType">
        <option value="">Do Follow</option>
        <option value="">No Foloow</option>
        </select>
        </div>
        <div class="col-md-12" style="margin-top: 15px;">
        <label>Website Language *</label>
        <select class="multisteps-form__input form-control select2-hidden-accessible" id="language" multiple="" name="language" data-select2-id="select2-data-language" tabindex="-1" aria-hidden="true">
        <option value="english" selected="" data-select2-id="select2-data-2-otza">English</option>
        <option value="espanol">Espanol</option>
        <option value="dutch">Dutch</option>
        <option value="turkish">Turkish</option>
        <option value="hindi">Hindi</option>
        <option value="urdu">Urdu</option>
        <option value="other">Other</option>
        </select><span class="select2 select2-container select2-container--default" dir="ltr" data-select2-id="select2-data-1-g49g" style="width: 872px;"><span class="selection"><span class="select2-selection select2-selection--multiple" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1" aria-disabled="false"><ul class="select2-selection__rendered" id="select2-language-container"><li class="select2-selection__choice" title="English" data-select2-id="select2-data-3-c3bw"><button type="button" class="select2-selection__choice__remove" tabindex="-1" title="Remove item" aria-label="Remove item" aria-describedby="select2-language-container-choice-o60b-english"><span aria-hidden="true">×</span></button><span class="select2-selection__choice__display" id="select2-language-container-choice-o60b-english">English</span></li></ul><span class="select2-search select2-search--inline"><input class="select2-search__field" type="search" tabindex="0" autocorrect="off" autocapitalize="none" spellcheck="false" role="searchbox" aria-autocomplete="list" autocomplete="off" aria-describedby="select2-language-container" placeholder="" style="width: 0.75em;"></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
        </div>
        <div class="col-md-12" style="margin-top: 15px;">
        <label>Select Categories: (Up to 3 Categories)*</label>
        <style>
                                            .cats-list li{
                                              width: 32.9%;
                                              display: inline-block;
                                            }
                                          </style>
        <ul class="cats-list" style="padding: 0;margin: 0;list-style-type: none;">
         <li>
        <label>
        <input type="checkbox" name="cat" value="7"> Automotive </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="8"> Business &amp; Finance </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="20"> Cryptocurrency </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="5"> Education </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="9"> Family &amp; Parenting </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="10"> Food &amp; Drink </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="11"> Gaming </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="24"> General: Multi-Niche </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="15"> Government &amp; Politics </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="6"> Health </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="14"> Home &amp; Architecture </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="21"> Pets </label>
        </li>
         <li>
        <label>
        <input type="checkbox" name="cat" value="17"> Podcasts </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="23"> Premium Websites </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="19"> SEO &amp; Digital Marketing </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="18"> Technology </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="12"> Travel </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="22"> Visual Arts &amp; Design </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="13"> Web Design &amp; Development </label>
        </li>
        <li>
        <label>
        <input type="checkbox" name="cat" value="16"> Weddings </label>
        </li>
        </ul>
        </div>
        </div>
        <div class="button-row d-flex mt-4">
        <button class="btn btn-primary btn-lg js-btn-prev" type="button" title="Prev">Prev</button>
        <button class="btn btn-primary btn-lg ml-auto js-btn-next" type="button" id="website_details_tab_next" title="Next">Next</button>
        </div>
        </div>
        </div>
        
        <div class="multisteps-form__panel shadow p-4 rounded bg-theme-color" data-animation="scaleIn">
        <h3 class="multisteps-form__title text-center font-weight-bold">Requirements</h3>
        <div class="multisteps-form__content">
        <div class="form-row mt-4">
        <div class="col-md-6" style="margin-top: 15px;">
        <label>Guest Post Price (in US Dollars) *</label>
        <select id="price" class="multisteps-form__input form-control">
        <option value="5">$5</option><option value="10">$10</option><option value="15">$15</option><option value="20">$20</option><option value="25">$25</option><option value="30">$30</option><option value="35">$35</option><option value="40">$40</option><option value="45">$45</option><option value="50">$50</option><option value="55">$55</option><option value="60">$60</option><option value="65">$65</option><option value="70">$70</option><option value="75">$75</option><option value="80">$80</option><option value="85">$85</option><option value="90">$90</option><option value="95">$95</option><option value="100">$100</option><option value="105">$105</option><option value="110">$110</option><option value="115">$115</option><option value="120">$120</option><option value="125">$125</option><option value="130">$130</option><option value="135">$135</option><option value="140">$140</option><option value="145">$145</option><option value="150">$150</option><option value="155">$155</option><option value="160">$160</option><option value="165">$165</option><option value="170">$170</option><option value="175">$175</option><option value="180">$180</option><option value="185">$185</option><option value="190">$190</option><option value="195">$195</option><option value="200">$200</option><option value="205">$205</option><option value="210">$210</option><option value="215">$215</option><option value="220">$220</option><option value="225">$225</option><option value="230">$230</option><option value="235">$235</option><option value="240">$240</option><option value="245">$245</option><option value="250">$250</option><option value="255">$255</option><option value="260">$260</option><option value="265">$265</option><option value="270">$270</option><option value="275">$275</option><option value="280">$280</option><option value="285">$285</option><option value="290">$290</option><option value="295">$295</option><option value="300">$300</option><option value="305">$305</option><option value="310">$310</option><option value="315">$315</option><option value="320">$320</option><option value="325">$325</option><option value="330">$330</option><option value="335">$335</option><option value="340">$340</option><option value="345">$345</option><option value="350">$350</option><option value="355">$355</option><option value="360">$360</option><option value="365">$365</option><option value="370">$370</option><option value="375">$375</option><option value="380">$380</option><option value="385">$385</option><option value="390">$390</option><option value="395">$395</option><option value="400">$400</option><option value="405">$405</option><option value="410">$410</option><option value="415">$415</option><option value="420">$420</option><option value="425">$425</option><option value="430">$430</option><option value="435">$435</option><option value="440">$440</option><option value="445">$445</option><option value="450">$450</option><option value="455">$455</option><option value="460">$460</option><option value="465">$465</option><option value="470">$470</option><option value="475">$475</option><option value="480">$480</option><option value="485">$485</option><option value="490">$490</option><option value="495">$495</option><option value="500">$500</option><option value="505">$505</option><option value="510">$510</option><option value="515">$515</option><option value="520">$520</option><option value="525">$525</option><option value="530">$530</option><option value="535">$535</option><option value="540">$540</option><option value="545">$545</option><option value="550">$550</option><option value="555">$555</option><option value="560">$560</option><option value="565">$565</option><option value="570">$570</option><option value="575">$575</option><option value="580">$580</option><option value="585">$585</option><option value="590">$590</option><option value="595">$595</option><option value="600">$600</option><option value="605">$605</option><option value="610">$610</option><option value="615">$615</option><option value="620">$620</option><option value="625">$625</option><option value="630">$630</option><option value="635">$635</option><option value="640">$640</option><option value="645">$645</option><option value="650">$650</option><option value="655">$655</option><option value="660">$660</option><option value="665">$665</option><option value="670">$670</option><option value="675">$675</option><option value="680">$680</option><option value="685">$685</option><option value="690">$690</option><option value="695">$695</option><option value="700">$700</option><option value="705">$705</option><option value="710">$710</option><option value="715">$715</option><option value="720">$720</option><option value="725">$725</option><option value="730">$730</option><option value="735">$735</option><option value="740">$740</option><option value="745">$745</option><option value="750">$750</option><option value="755">$755</option><option value="760">$760</option><option value="765">$765</option><option value="770">$770</option><option value="775">$775</option><option value="780">$780</option><option value="785">$785</option><option value="790">$790</option><option value="795">$795</option><option value="800">$800</option><option value="805">$805</option><option value="810">$810</option><option value="815">$815</option><option value="820">$820</option><option value="825">$825</option><option value="830">$830</option><option value="835">$835</option><option value="840">$840</option><option value="845">$845</option><option value="850">$850</option><option value="855">$855</option><option value="860">$860</option><option value="865">$865</option><option value="870">$870</option><option value="875">$875</option><option value="880">$880</option><option value="885">$885</option><option value="890">$890</option><option value="895">$895</option><option value="900">$900</option><option value="905">$905</option><option value="910">$910</option><option value="915">$915</option><option value="920">$920</option><option value="925">$925</option><option value="930">$930</option><option value="935">$935</option><option value="940">$940</option><option value="945">$945</option><option value="950">$950</option><option value="955">$955</option><option value="960">$960</option><option value="965">$965</option><option value="970">$970</option><option value="975">$975</option><option value="980">$980</option><option value="985">$985</option><option value="990">$990</option><option value="995">$995</option><option value="1000">$1000</option> </select>
        <span class="text-muted">You will receive: <strong id="reveiceAmount" class="text-danger">$4.5</strong></span>
        </div>
        <div class="col-md-6" style="margin-top: 15px;">
        <label>Delivery Time (in Days) *</label>
        <input type="text" id="delivery" name="delivery" value="10" class="multisteps-form__input form-control">
        </div>
        <div class="col-md-6" style="margin-top: 15px;">
        <label>Guest post Content Included? *</label>
        <select class="multisteps-form__input form-control" id="contentStatus" onchange="gpPrice()">
        <option value="1">Yes, Content Included</option>
        <option value="0">No, Content Not Included</option>
        </select>
        <div class="form-row mt-3" id="contentPrice" style="display:none;">
        <div class="col-md-12" style="padding: unset;">
        <label>Can you write content? if Yes, mention price for content below</label>
        <input type="number" name="content-price" id="content-price" placeholder="Content Price  (in US Dollars)" class="multisteps-form__input form-control">
        </div>
        </div>
        </div>
         <div class="col-md-6" style="margin-top: 15px;">
        <label>Words Limit for guest post (Min. 300) *</label>
        <input type="text" value="300" id="words" name="words" class="multisteps-form__input form-control">
        </div>
        <div class="col-md-12" style="margin-top: 15px;">
        <label>Guest Post Samples / one link on each line (Max. 3) *</label>
        <textarea class="multisteps-form__input form-control" id="samples" name="samples" rows="3"></textarea>
        </div>
        </div>
        <div class="button-row d-flex mt-4">
        <button class="btn btn-primary btn-lg js-btn-prev" type="button" title="Prev">Prev</button>
        <button class="btn btn-primary btn-lg ml-auto js-btn-next" id="website_requirements_tab_next" type="button" title="Next">Next</button>
        </div>
        </div>
        </div>
        <div class="multisteps-form__panel shadow p-4 rounded bg-theme-color" data-animation="scaleIn">
        <h3 class="multisteps-form__title text-center font-weight-bold">About Website</h3>
        <div class="multisteps-form__content">
        <div class="form-row mt-4">
        <div class="col-md-12" style="margin-top: 15px;">
        <label>Details About Website: (Optional)</label>
        <label class="text-info">(Write 300+ words to get in the recommended List)</label>
        <span class="pull-right text-muted"><span class="text-success" id="detailsWords">0</span> Words</span>
        
        <textarea name="details" id="webDetails" class="multisteps-form__input form-control" rows="6"></textarea>
        </div>
        </div>
        <div class="button-row d-flex mt-4">
        <button class="btn btn-primary btn-lg js-btn-prev" type="button" title="Prev">Prev</button>
        <button class="btn btn-success btn-lg ml-auto" type="button" id="next2" title="Send">Submit</button>
        </div>
        </div>
        </div>
        </form>
        <div class="col-md-12 noP addsection text-center" id="addSec-2" style="display:none;">
        <p>
        <i class="fa fa-check text-success" style="font-size:75px; border:1px solid #5B922E; border-radius:50%; padding:10px;"></i>
        </p>
        <p>
        <strong class="text-uppercase">Website Submitted</strong>
        </p>
        <hr>
        <p>
        Your Website is submitted successfully, our team will review your website and notify you
        if it's approved.
        </p>
        </div>
        </div>
        </div>
        </div>
        
        </div>
        </div>
        </div>
        </div>-->

    
</div>
