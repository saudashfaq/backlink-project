<div class="categories">
        <strong class="strongC">Categories / <span class="spanC">see all <i
                    class="fas fa-angle-double-right"></i></span></strong>
        <div class="ulC">
            <a href="{{ route('buy.category') }}" class="categorie">
                Automovile
            </a>
        </div>
    </div>
