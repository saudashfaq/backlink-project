<?php return array (
  'category-list' => 'App\\Http\\Livewire\\CategoryList',
  'filter-website' => 'App\\Http\\Livewire\\FilterWebsite',
  'footer' => 'App\\Http\\Livewire\\Footer',
  'form-progress' => 'App\\Http\\Livewire\\FormProgress',
  'form-register' => 'App\\Http\\Livewire\\FormRegister',
  'header' => 'App\\Http\\Livewire\\Header',
  'heading' => 'App\\Http\\Livewire\\Heading',
  'heading2' => 'App\\Http\\Livewire\\Heading2',
  'heading-category' => 'App\\Http\\Livewire\\HeadingCategory',
  'marketplaces' => 'App\\Http\\Livewire\\Marketplaces',
  'register' => 'App\\Http\\Livewire\\Register',
  'website-add' => 'App\\Http\\Livewire\\WebsiteAdd',
);