<footer class="footer">
    <div class="firtSection">
            <div class="footer__links">
                <a class="linksF" href="<?php echo e(route('marketplace')); ?>">Buy gues posts</a>
                <a class="linksF" href="<?php echo e(route('sell-guest-posts')); ?>">Sell gues post</a>
                <a class="linksF" href="<?php echo e(route('marketplace')); ?>">Marketplace</a>
                <a class="linksF" href="<?php echo e(route('contact.index')); ?>">Contact</a>
            </div>
            <hr class="fS">
            <div class="footer__description">
                Buy-Sell Guest Post is a platform that merchandise guest posts only with no limitation to minimum guest
                posts or any SEO metrics. Further, there’s no evaluation for home page features or any other
                requirements.
            </div>
            <div class="social">
                <i class="socialIcons fab fa-facebook-f"></i>
                <i class="socialIcons fab fa-twitter"></i>
            </div>
    </div>
    <div class="secondSection">
            &copy; 2020 BuySellGuestPost.com
            <div class="secondSectionLink">
                <a class="sSecLink" href="<?php echo e(route('faqs')); ?>">FAQs</a>
                <a class="sSecLink" href="<?php echo e(route('term')); ?>">Terms</a>
                <a class="sSecLink" href="<?php echo e(route('privacy')); ?>">Privacy</a>
                <a class="sSecLink" href="<?php echo e(route('refound-policy')); ?>">Refunds</a>
            </div>
    </div>
</footer>
<?php /**PATH /home/u868454385/domains/consulfinhn.com/public_html/websitetwo/resources/views/livewire/footer.blade.php ENDPATH**/ ?>