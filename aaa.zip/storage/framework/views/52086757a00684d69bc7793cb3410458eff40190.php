<nav class="navigation" id="nav">
    <div class="nav">
        <div class="cMenuT">
            <a href="/">
                <img src="<?php echo e(asset('img/logo.png')); ?>" class="nav__link--logo" alt="Logo Website">
            </a>
            <div id="menuT" class="navigation__menuT">
                <i class="fas fa-bars"></i>
            </div>
        </div>
        <div class="contMenu desactive" id="contNav">
            <div class="nav__link">
                <ul class="nav__link--navbar">
                    <li class="navbar">
                        <a class="navbar__link" href="<?php echo e(route('sell-guest-posts')); ?>">Sell Guest Posts</a>
                    </li>
                    <li class="navbar">
                        <a class="navbar__link" href="<?php echo e(route('marketplace')); ?>">Marketplace</a>
                    </li>
                    <li class="navbar">
                        <a class="navbar__link" href="<?php echo e(route('guest-posting-services')); ?>">Guest Posting Services</a>
                    </li>
                    <li class="navbar">
                        <a class="navbar__link" href="<?php echo e(route('da-dr-increase-service')); ?>">Increase DA/DR</a>
                    </li>
                </ul>
            </div>
            <?php
                $cont = \DB::table('carts')
                    ->count();
                //return dd($cont);
            ?>
            <div class="nav__cardAndLogin">
                <!--<ul class="nav__cardAndLogin--ul">-->
                    <ul style="display: flex; align-items: center;">
                    <a class="cart" href="<?php echo e(route('cart.show', $cont)); ?>">



                        <li class="navbar"><i class="fas fa-cart-plus cart"></i><a class="navbar__link cart-item" href="<?php echo e(route('cart.show', $cont)); ?>" style="border-right: 1px solid #123147;"><?php echo e($cont); ?> item</a></li>
                    <!--</a>-->
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="login"><a href="<?php echo e(route('login')); ?>" style="cursor: pointer;">Login</a></li>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                        <li class="navbar">
                            <a role="button" id="userButton" class="navbar__link" style="cursor: pointer;">
                                <?php echo e(auth()->user()->first_name); ?> <i class="fas fa-caret-down"></i>
                            </a>
                        </li>

                        <div class="dropdown-user" style="display: none;">
                            <div class="buyer-seller">
                                <a href="<?php echo e(route('advertiser.index')); ?>">Buyer</a>
                                <a href="<?php echo e(route('publisher.index')); ?>">Seller</a>
                            </div>
                            <a href="<?php echo e(route('user.edit')); ?>">My Profile</a>
                            <a href="<?php echo e(route('advertiser.index')); ?>">Transactions History</a>
                            <a href="">Balance: $0</a>
                            <div>
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>

                            </div>
                        </div>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH /home/u868454385/domains/consulfinhn.com/public_html/websitetwo/resources/views/livewire/header.blade.php ENDPATH**/ ?>