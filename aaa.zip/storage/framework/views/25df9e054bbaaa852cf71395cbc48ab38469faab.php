<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('page-title'); ?></title>

    <!-- Here we add Roboto Font of Google -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" id="fontsGoogle">

    <!-- Here we use fontawesome 5.15.1 -->
    <script src="<?php echo e(asset('js/allFontAwesome.js')); ?>"></script>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://js.stripe.com/v3/"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

    <?php echo $__env->yieldContent('custom_js_head'); ?>
    

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('css/normalize.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/select2.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/btcustom.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::styles(); ?>


    <?php echo $__env->yieldContent('custom_css'); ?>

</head>
<body>
 
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('header', [])->html();
} elseif ($_instance->childHasBeenRendered('JWw7NXK')) {
    $componentId = $_instance->getRenderedChildComponentId('JWw7NXK');
    $componentTag = $_instance->getRenderedChildComponentTagName('JWw7NXK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JWw7NXK');
} else {
    $response = \Livewire\Livewire::mount('header', []);
    $html = $response->html();
    $_instance->logRenderedChild('JWw7NXK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    <?php echo $__env->yieldContent('content'); ?>


    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer', [])->html();
} elseif ($_instance->childHasBeenRendered('8qMcxt2')) {
    $componentId = $_instance->getRenderedChildComponentId('8qMcxt2');
    $componentTag = $_instance->getRenderedChildComponentTagName('8qMcxt2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8qMcxt2');
} else {
    $response = \Livewire\Livewire::mount('footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('8qMcxt2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('custom_js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH /home/u868454385/domains/consulfinhn.com/public_html/websitetwo/resources/views/layouts/app.blade.php ENDPATH**/ ?>