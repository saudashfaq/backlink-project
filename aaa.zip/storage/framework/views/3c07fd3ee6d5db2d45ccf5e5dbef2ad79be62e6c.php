<?php $__env->startSection('page-title', "Buy - Amit's Website"); ?>

<?php $__env->startSection('custom_css'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/mp.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/heading-category.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/buy.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('filter-website', ['cateslug' => $cateslug,'categories' => $categories,'tlds' => $tlds,'languages' => $languages,'websites2' => $websites2,'catego' => $catego,'numCarts' => $numCarts])->html();
} elseif ($_instance->childHasBeenRendered('eFfTVRn')) {
    $componentId = $_instance->getRenderedChildComponentId('eFfTVRn');
    $componentTag = $_instance->getRenderedChildComponentTagName('eFfTVRn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eFfTVRn');
} else {
    $response = \Livewire\Livewire::mount('filter-website', ['cateslug' => $cateslug,'categories' => $categories,'tlds' => $tlds,'languages' => $languages,'websites2' => $websites2,'catego' => $catego,'numCarts' => $numCarts]);
    $html = $response->html();
    $_instance->logRenderedChild('eFfTVRn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>

<script>

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u868454385/domains/consulfinhn.com/public_html/websitetwo/resources/views/buy/index.blade.php ENDPATH**/ ?>