<div>
    <div>
         <div class="names">

            <div class="cFName">
                <label for="first_name" class="label">First Name</label>
                <input wire:model="first_name" type="text" placeholder="First Name" class="input" value="<?php echo e(old('first_name')); ?>">
                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="error" role="alert">
                    <strong style="color: #dc3545; display: block; margin-bottom: 1rem;"><?php echo e($message); ?></strong>
                </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="lFName">
                <label for="last_name" class="label">Last Name</label>
                <input wire:model="last_name" type="text" placeholder="Last Name" class="input" value="<?php echo e(old('last_name')); ?>">
                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="error" role="alert">
                    <strong style="color: #dc3545; display: block; margin-bottom: 1rem;"><?php echo e($message); ?></strong>
                </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>

        <label for="email" class="label">Email</label>
        <input wire:model="email" type="email" placeholder="Example: info@yourcompany.com" class="input" value="<?php echo e(old('email')); ?>">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="error" role="alert">
            <strong style="color: #dc3545; display: block; margin-bottom: 1rem;"><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="password" class="label">Password</label>
        <input wire:model="password" type="password"  placeholder="Password" class="input">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="error" role="alert">
            <strong style="color: #dc3545; display: block; margin-bottom: 1rem;"><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <span>
        By Registering, You Agree To <a href="/privacy" class="formLinks">The Privacy Policy</a>, <a
                    href="/refunds" class="formLinks">Refund Policy</a> & <a href="/term"
                                                                             class="formLinks">Terms Of
            Services.</a>
        </span>

        <div class="submit">
            <button type="button" wire:click="submit()" class="btn" style="cursor: pointer;">
                Register Now
            </button>
        </div>
    </div>
       

</div>
<?php /**PATH /home/u868454385/domains/consulfinhn.com/public_html/websitetwo/resources/views/livewire/form-register.blade.php ENDPATH**/ ?>